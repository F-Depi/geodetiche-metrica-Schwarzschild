Unofficial template for UniTN Degree Thesis. Final draft 28.02.2022.

Mainly based on: 
    - https://it.overleaf.com/latex/templates/template-tesi-triennale/qjpshtvmfbph
    - https://it.overleaf.com/latex/templates/ulbreport-template/jzjgsqbnswmw

It contains everything necessary to write a bachelor thesis

Per iniziare a scrivere:
 - si può togliere il pacchetto lipsum
 - si consiglia di fare attenzione a non cancellare le entries a glossario, nomenclatura, bibliografia e indice analitico (non avere richiami nel testo può dare problemi) 

Problemi con il pacchetto pagesel: a filigrana in prima pagina ha opacità massima con questa opzione attivata (non mettendo la prima pagina comunque appare 'draft' in background)